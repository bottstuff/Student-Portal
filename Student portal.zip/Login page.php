<html>
<head>
<title>Index page</title>
</head>
<body>
	<center>
		<h1>Employee portal</h1>
		<br>
		<br>
		<h3>
			<a href="home.php">Home</a> 
			&nbsp &nbsp
			<a href="ContactUS.php">Contact Us</a>
			&nbsp &nbsp
			<a href="login.php">Login</a>
			&nbsp &nbsp
			<a href="Registration.php">Registration</a>
		</h3>
		<br>
		<h3>New employees register here</h3>
		<form>
			<table>
				<tr><td>First & Last Name : </td><td><input type = "text" name = "FullName"></td></tr>
				<tr><td>Email : </td><td> <input type = "text" name = "Email"></td></tr>
				<tr><td>Password :  </td><td> <input type = "password" name = "password"></td></tr>
				<tr><td>Repeat Password : </td><td> <input type = "password" name = "password"></td></tr>
				<tr><td></td><td><input type = "submit" value = "Register"></td></tr>
			</table>
				<p>Already have an account? <a href="login.php">Login</a></p>
		</form>
	</center>
</body>
</html>


