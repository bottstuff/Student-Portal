<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Contact US </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/boostrap/3.3.6/css/bootstrap.min.css">
	<script src="http://ajaxgoogleapis.com/ajax/libs/jquery/1.12.0.jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/boostrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';
?>


	<div class="container text-center">
      <h1>ContactUS</h1>
	  <h2>Office Number: (555) 555-5555</h2>
	  <h2>Office Email: Info@ContactUs.com</h2>
	</div>
	

<?php require_once 'footer.php';?>
</body>
</html>