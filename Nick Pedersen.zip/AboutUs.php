<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> About US </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/boostrap/3.3.6/css/bootstrap.min.css">
	<script src="http://ajaxgoogleapis.com/ajax/libs/jquery/1.12.0.jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/boostrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>


	<div class="container text-center">
      <h1>About US</h1>
	  <h3>Padget Technologies is a leading provider of robotics, automation, and custom engineered industrial manufacturing solutions.  Founded in 1983 as Diedrichs and Associates, we built our reputation by providing unique engineered solutions for research and development, manufacturing, and testing.  Since being purchased by former employee Dennis Padget, we have utilized our experience to become one of the foremost providers of automated solutions, test stand, and custom machines in the Midwest.  We want to provide these services for you.  Visit our services page to see what we can offer, or better yet, contact us and find out right away how we can solve your automation challenges.</h3>
	</div>
	

<?php require_once 'footer.php';?>
</body>
</html>