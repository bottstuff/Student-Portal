<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Registration Page </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/boostrap/3.3.6/css/bootstrap.min.css">
	<script src="http://ajaxgoogleapis.com/ajax/libs/jquery/1.12.0.jquery.min.js"></script>
	<script src="htpp://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>

<div class="container text-center">
	<h1>Welcome to the Registration page</h1>
		<br>
		<h3>Please fill in all fields</h3>
			<form>
				<center>
				<table>
				<tr><td>First Name : </td><td><input type = "text" name = "FirstName"></td></tr>
				<tr><td>Last Name : </td><td><input type = "text" name = "LastName"></td></tr>
				<tr><td>Address : </td><td><input type = "text" name = "Address"></td></tr>
				<tr><td>Phone Number : </td><td><input type = "text" name = "PhoneNumber"></td></tr>
				<tr><td>Student ID : </td><td><input type = "text" name = "Student ID"></td></tr>
				<tr><td>Social Security Number : </td><td><input type = "text" name = "SSN"></td></tr>
				<tr><td>Email : </td><td> <input type = "text" name = "Email"></td></tr>
				<tr><td>Password :  </td><td> <input type = "password" name = "password"></td></tr>
				<tr><td></td><td><input type = "submit" value = "Register"></td></tr>
				</table>
				</center>
				<p>Already have an account? <a href="login.php">Login</a></p>
			</form>
</center>
</body>
</html>

<?php include 'footer.php';?>
</body>
</html>
